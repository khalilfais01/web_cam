# Advanced Digital Forensics Challenge 🕵️

## Scenario
A sophisticated attacker compromised a high-security system. Your task is to analyze the collected forensic evidence and reconstruct the attack timeline to recover the hidden flag.

## Evidence Files
- `memory_dump.raw` - System memory dump (1MB)
- `suspicious_binary` - Corrupted executable found on system
- `network_capture.pcap` - Network traffic during incident
- `encrypted_database.db` - SQLite database with encrypted data
- `registry_dump.json` - Windows registry snapshot
- `system.log` - System event log
- `application.log` - Application debug log

## Challenge Requirements
This is a **REAL** forensics challenge requiring:
- Binary analysis skills
- Memory forensics techniques  
- Cryptographic analysis
- Network traffic analysis
- Database investigation
- Log correlation

## Tools You'll Need
- Hex editor (HxD, xxd)
- Strings utility
- SQLite browser
- Wireshark (for PCAP analysis)
- Python for decryption/decoding
- Memory analysis tools

## Flag Format
`KYBS{...}`

## Difficulty Level
🔥🔥🔥🔥🔥 **EXPERT**

## Hints
1. The flag is scattered across multiple evidence sources
2. Look for patterns in memory at specific offsets
3. Some data is encoded, others are encrypted
4. Correlation between different evidence types is key
5. The timeline in logs provides crucial context

## Scoring
- Flag discovery: 100 points
- Bonus: Document your complete analysis methodology for +50 points

**This challenge simulates real-world digital forensics. No simple API calls!**
